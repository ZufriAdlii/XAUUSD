// Netlify Function: proksi ke Google Gemini API (tier percuma) supaya API key tidak terdedah di browser.
// Tetapkan GEMINI_API_KEY dalam Netlify > Site configuration > Environment variables.

// Model Flash ada tier percuma. Jika model ini ditamatkan, tukar ke nama model Flash terkini
// yang tertera di Google AI Studio (contoh: "gemini-2.5-flash-lite").
const MODEL = "gemini-2.5-flash";

export default async (req) => {
  if (req.method !== "POST") return new Response("Method not allowed", { status: 405 });

  const key = process.env.GEMINI_API_KEY;
  if (!key) return Response.json({ error: "API key belum ditetapkan" }, { status: 500 });

  let prompt;
  try { ({ prompt } = await req.json()); } catch { return Response.json({ error: "JSON tidak sah" }, { status: 400 }); }
  if (typeof prompt !== "string" || !prompt.trim() || prompt.length > 4000) {
    return Response.json({ error: "Prompt tidak sah" }, { status: 400 });
  }

  const url = `https://generativelanguage.googleapis.com/v1beta/models/${MODEL}:generateContent`;
  const r = await fetch(url, {
    method: "POST",
    headers: { "x-goog-api-key": key, "content-type": "application/json" },
    body: JSON.stringify({
      systemInstruction: { parts: [{ text: "Pulangkan JSON sahaja. Tiada teks lain, tiada markdown." }] },
      contents: [{ role: "user", parts: [{ text: prompt }] }],
      generationConfig: { responseMimeType: "application/json", maxOutputTokens: 1000, temperature: 0.4 },
    }),
  });

  // 429 = had percuma (per minit / per hari) sudah dicapai
  if (r.status === 429) return Response.json({ error: "rate_limited" }, { status: 429 });
  if (!r.ok) return Response.json({ error: "Ralat API", detail: await r.text() }, { status: 502 });

  const data = await r.json();
  const text = (data.candidates?.[0]?.content?.parts || []).map(p => p.text || "").join("");
  const clean = text.replace(/```json|```/g, "").trim();
  try {
    return Response.json(JSON.parse(clean));
  } catch {
    return Response.json({ error: "Jawapan AI bukan JSON" }, { status: 502 });
  }
};
