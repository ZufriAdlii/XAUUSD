// Netlify Function: tarik kalendar ForexFactory (feed JSON percuma, tidak rasmi)
// dan pulangkan acara USD berimpak sederhana/tinggi untuk minggu ini.
// Feed ini hanya ada ramalan & angka sebelum, bukan angka sebenar.
// Tiada API key diperlukan.

const FEEDS = [
  "https://nfs.faireconomy.media/ff_calendar_thisweek.json",
  "https://nfs.faireconomy.media/ff_calendar_nextweek.json", // diabaikan jika tiada
];

export default async () => {
  const out = [];
  const seen = new Set();
  let ok = false;

  for (const url of FEEDS) {
    try {
      const r = await fetch(url, { headers: { "user-agent": "RadarEmas/1.0" } });
      if (!r.ok) continue;
      const list = await r.json();
      if (!Array.isArray(list)) continue;
      ok = true;
      for (const e of list) {
        if (e.country !== "USD" || !["High", "Medium"].includes(e.impact)) continue;
        const id = e.title + "|" + e.date;
        if (seen.has(id)) continue;
        seen.add(id);
        out.push({
          title: e.title,
          date: e.date,
          forecast: e.forecast || "",
          previous: e.previous || "",
          actual: e.actual || "",
        });
      }
    } catch {}
  }

  if (!ok) return Response.json({ error: "Feed ForexFactory tidak dapat dicapai" }, { status: 502 });

  // Cache 30 minit di CDN Netlify supaya tidak kena had kadar ForexFactory
  return Response.json(out, {
    headers: {
      "cache-control": "public, max-age=300",
      "netlify-cdn-cache-control": "public, s-maxage=1800, stale-while-revalidate=3600",
    },
  });
};
